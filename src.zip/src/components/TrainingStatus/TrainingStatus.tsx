import React, { useState } from 'react';
import styles from './TrainingStatus.module.css';
import Modal from '../Modal/Modal';
import AddTrainingForm from '../AddTrainingForm/AddTrainingForm';
import trainingIcon from '../../assets/image.png';

interface TrainingData {
  activityType: string;
  load: number;
  heartRate: number;
  time: string;
  distance: string;
}

interface StatusConfig {
  text: string;
  color: string;
}

const getStatusConfig = (load: number): StatusConfig => {
  if (load >= 1 && load <= 2) {
    return { text: 'Непродуктивная', color: '#FC0000' };
  } else if (load >= 3 && load <= 4) {
    return { text: 'Восстановление', color: '#1D00FC' };
  } else if (load >= 5 && load <= 6) {
    return { text: 'Поддерживающий', color: '#00FC4C' };
  } else if (load >= 7 && load <= 8) {
    return { text: 'Продуктивная', color: '#E700FC' };
  } else if (load >= 9 && load <= 10) {
    return { text: 'Пиковая нагрузка', color: '#CB03D9' };
  }
  return { text: 'Статус недоступен', color: '#000000' };
};

const TrainingStatus: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [trainingData, setTrainingData] = useState<TrainingData | null>(null);

  const calculatePace = (time: string, distance: string): string => {
    const timeParts = time.split(':').map(Number);
    const totalSeconds = timeParts[0] * 3600 + timeParts[1] * 60 + timeParts[2];
    const totalMinutes = totalSeconds / 60;
    
    const distanceKm = parseFloat(distance);
    if (distanceKm === 0) return '';
    
    const paceMinutes = totalMinutes / distanceKm;
    const paceMin = Math.floor(paceMinutes);
    const paceSec = Math.round((paceMinutes - paceMin) * 60);
    
    return `${paceMin}:${paceSec.toString().padStart(2, '0')}`;
  };

  const handleAddTraining = (data: TrainingData) => {
    setTrainingData(data);
    setIsModalOpen(false);
  };

  const statusConfig = trainingData 
    ? getStatusConfig(trainingData.load) 
    : { text: 'Статус недоступен', color: '#000000' };

  return (
    <div className={styles.container}>
      <h3 className={styles.title}>Статус тренировки</h3>
      
      <div className={styles.statusSection}>
        <div 
          className={styles.indicatorImage}
          style={{ 
            backgroundColor: statusConfig.color,
            maskImage: `url(${trainingIcon})`,
            WebkitMaskImage: `url(${trainingIcon})`
          }}
        />
        <div className={styles.statusText}>{statusConfig.text}</div>
      </div>
      
      <div className={styles.metrics}>
        <h4>Показатели:</h4>
        <div className={styles.metricItem}>
          Нагрузка: {trainingData ? `${trainingData.load}/10` : ''}
        </div>
        <div className={styles.metricItem}>
          Темп: {trainingData ? `${calculatePace(trainingData.time, trainingData.distance)} мин/км` : ''}
        </div>
        <div className={styles.metricItem}>
          Пульс: {trainingData?.heartRate ? `${trainingData.heartRate} уд/мин` : ''}
        </div>
        <div className={styles.metricItem}>
          Время: {trainingData?.time ? `${trainingData.time} ч:мин:с` : ''}
        </div>
        <div className={styles.metricItem}>
          Дистанция: {trainingData?.distance ? `${trainingData.distance} км` : ''}
        </div>
      </div>
      
      <button 
        className={styles.button}
        onClick={() => setIsModalOpen(true)}
      >
        Добавить тренировку
      </button>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
        <AddTrainingForm 
          onSubmit={handleAddTraining}
          onCancel={() => setIsModalOpen(false)}
        />
      </Modal>
    </div>
  );
};

export default TrainingStatus;