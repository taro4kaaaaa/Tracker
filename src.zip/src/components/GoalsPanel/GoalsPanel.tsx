import React from 'react';
import styles from './GoalsPanel.module.css';

const GoalsPanel: React.FC = () => {
  return (
    <div className={styles.panel}>
      <section className={styles.section}>
        <h3 className={styles.sectionTitle}>Цели:</h3>
        <ul className={styles.list}>
          <li>Марафон за 2:20:25</li>
          <li>5 км из 25 мин</li>
          <li>4 тренировки в неделю</li>
        </ul>
      </section>
      
      <section className={styles.section}>
        <h3 className={styles.sectionTitle}>Соревнования:</h3>
        <ul className={styles.list}>
          <li>
            <div>Марафон Токио</div>
            <div className={styles.date}>25.04.2026</div>
          </li>
          <li>
            <div>10км Питер</div>
            <div className={styles.date}>21.05.2026</div>
          </li>
        </ul>
      </section>
      
      <div className={styles.buttons}>
        <button className={styles.button}>Добавить цель</button>
        <button className={styles.button}>Добавить соревнование</button>
      </div>
    </div>
  );
};

export default GoalsPanel;