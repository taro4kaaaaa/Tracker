import React from 'react';
import styles from './WeekCalendar.module.css';

const WeekCalendar: React.FC = () => {
  const days = [
    { day: 'Пн', date: '11.05', color: 'green' },
    { day: 'Вт', date: '12.05', color: null },
    { day: 'Ср', date: '13.05', color: 'green' },
    { day: 'Чт', date: '14.05', color: 'red' },
    { day: 'Пт', date: '15.05', color: 'purple' },
    { day: 'Сб', date: '16.05', color: 'red' },
    { day: 'Вс', date: '17.05', color: 'purple' },
  ];

  return (
    <div className={styles.calendar}>
      {days.map((day, index) => (
        <div key={index} className={styles.day}>
          <div className={styles.dayHeader}>
            <span className={styles.dayName}>{day.day}</span>
            <span className={styles.dayDate}>{day.date}</span>
          </div>
          <div className={styles.indicators}>
            {day.color && (
              <div className={`${styles.indicator} ${styles[day.color]}`} />
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default WeekCalendar;