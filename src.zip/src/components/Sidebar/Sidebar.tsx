import { NavLink } from 'react-router-dom';
import styles from './Sidebar.module.css';

const Sidebar = () => {
  return (
    <div className={styles.sidebar}>
      <nav className={styles.nav}>
        <NavLink
          to="/"
          className={({ isActive }) => 
            `${styles.menuItem} ${isActive ? styles.active : ''}`
          }
          end
        >
          Главная
        </NavLink>
        <NavLink
          to="/calendar"
          className={({ isActive }) => 
            `${styles.menuItem} ${isActive ? styles.active : ''}`
          }
        >
          Календарь
        </NavLink>
        <NavLink
          to="/statistics"
          className={({ isActive }) => 
            `${styles.menuItem} ${isActive ? styles.active : ''}`
          }
        >
          Статистика показателей
        </NavLink>
        <NavLink
          to="/training"
          className={({ isActive }) => 
            `${styles.menuItem} ${isActive ? styles.active : ''}`
          }
        >
          Занятия
        </NavLink>
      </nav>
    </div>
  );
};

export default Sidebar;
