import React from 'react';
import styles from './ActivityMetrics.module.css';

const ActivityMetrics: React.FC = () => {
  const metrics = [
    { label: 'Ср. пульс', value: 56, size: 'large' },
    { label: 'Шаги', value: '0/10000', size: 'large' },
    { label: 'Стресс', value: 40, size: 'large' },
    { label: 'VO2 max', value: 56, size: 'small' },
    { label: 'Recovery', value: 100, size: 'small' },
  ];

  return (
    <div className={styles.container}>
      <h2 className={styles.title}>Активность за день</h2>
      <div className={styles.metrics}>
        {metrics.slice(0, 3).map((metric, index) => (
          <div key={index} className={styles.metric}>
            <div className={`${styles.circle} ${styles[metric.size]}`}>
              {metric.value}
            </div>
            <div className={styles.label}>{metric.label}</div>
          </div>
        ))}
      </div>
      <div className={styles.metrics}>
        {metrics.slice(3).map((metric, index) => (
          <div key={index} className={styles.metric}>
            <div className={`${styles.circle} ${styles[metric.size]}`}>
              {metric.value}
            </div>
            <div className={styles.label}>{metric.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ActivityMetrics;