import { Routes, Route } from 'react-router-dom';
import Layout from './widgets/Layout/Layout';
import Home from './pages/Home/Home';
import Calendar from './pages/Calendar/Calendar';
import Statistics from './pages/Statistics/Statistics';
import Training from './pages/Training/Training';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="calendar" element={<Calendar />} />
        <Route path="statistics" element={<Statistics />} />
        <Route path="training" element={<Training />} />
      </Route>
    </Routes>
  );
}

export default App;
