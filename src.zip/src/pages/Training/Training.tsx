import styles from './Training.module.css';

const Training = () => {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Занятия</h1>
      <p className={styles.placeholder}>Страница в разработке...</p>
    </div>
  );
};

export default Training;
