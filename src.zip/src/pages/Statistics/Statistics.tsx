import styles from './Statistics.module.css';

const Statistics = () => {
  return (
    <div className={styles.container}>
      <h1 className={styles.title}>Статистика показателей</h1>
      <p className={styles.placeholder}>Страница в разработке...</p>
    </div>
  );
};

export default Statistics;
